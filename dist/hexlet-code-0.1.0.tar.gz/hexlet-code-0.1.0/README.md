### Hexlet tests and linter status:
[![Actions Status](https://github.com/OlegKarush/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/OlegKarush/python-project-49/actions)

### Maintainability
<a href="https://codeclimate.com/github/OlegKarush/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7fe17029a88072af372a/maintainability" /></a>

### asciinema brain-even
[![asciicast](https://asciinema.org/a/DTP4YOwu3M0ah9jbZUVQ3WgYT.svg)](https://asciinema.org/a/DTP4YOwu3M0ah9jbZUVQ3WgYT)

### asciinema brain-calc
[![asciicast](https://asciinema.org/a/nHa8inAe3wlSmRp0yubtpMJnZ.svg)](https://asciinema.org/a/nHa8inAe3wlSmRp0yubtpMJnZ)

### asciinema brain-gcd
[![asciicast](https://asciinema.org/a/Bzn2sP6zL2aZxDhzQ5sVmHyUv.svg)](https://asciinema.org/a/Bzn2sP6zL2aZxDhzQ5sVmHyUv)

### asciinema brain-progression
[![asciicast](https://asciinema.org/a/hdbcQS4G2sKqU7axjuZiMivM9.svg)](https://asciinema.org/a/hdbcQS4G2sKqU7axjuZiMivM9)

### asciinema brain-prime
[![asciicast](https://asciinema.org/a/rhqameexqYPeb34R3seRrfUom.svg)](https://asciinema.org/a/rhqameexqYPeb34R3seRrfUom)