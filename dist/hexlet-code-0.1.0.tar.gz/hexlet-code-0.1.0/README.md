### Hexlet tests and linter status:
[![Actions Status](https://github.com/OlegKarush/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/OlegKarush/python-project-49/actions)

### бейджик Maintainability
<a href="https://codeclimate.com/github/OlegKarush/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7fe17029a88072af372a/maintainability" /></a>

### asciinema brain-even
https://asciinema.org/a/DTP4YOwu3M0ah9jbZUVQ3WgYT
