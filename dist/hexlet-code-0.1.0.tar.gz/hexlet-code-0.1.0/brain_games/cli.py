def welcome_user():
    import prompt
    welcome_user = prompt.string("May I have your name? ")

welcome_user()
