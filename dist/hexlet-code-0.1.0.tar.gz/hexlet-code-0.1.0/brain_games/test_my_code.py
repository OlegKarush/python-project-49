
text = 't11'
print(text.isalnum())