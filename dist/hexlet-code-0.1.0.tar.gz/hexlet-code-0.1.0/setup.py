# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Games to train your brain, just in Python.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/OlegKarush/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/OlegKarush/python-project-49/actions)\n\n### Maintainability\n<a href="https://codeclimate.com/github/OlegKarush/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7fe17029a88072af372a/maintainability" /></a>\n\n# Brain Games\n\nFive mathematical logic games that run on the terminal. 100% Python3.\n\nYou need to answer three questions in each game. If the answer is wrong, the game needs to start over.\n\n## Installation\n\nMake sure you are running at least Python 3.6.0\n\nClone the repository and install manually:\n\n```bash\n$ git clone https://github.com/OlegKarush/python-project-49.git\n```\n\n## Start Game\n\nTo start the game, run the necessary command.\n\n## Brain Even\n\n### Instructions:\n\nEnter the command: brain-even\n\nAnswer the question: Answer "yes" if the number is even, otherwise answer "no".\n\n[![asciicast](https://asciinema.org/a/DTP4YOwu3M0ah9jbZUVQ3WgYT.svg)](https://asciinema.org/a/DTP4YOwu3M0ah9jbZUVQ3WgYT)\n\n## Brain Calc\n\n### Instructions:\n\nEnter the command: brain-calc\n\nAnswer the question: What is the result of the expression?\n\n[![asciicast](https://asciinema.org/a/nHa8inAe3wlSmRp0yubtpMJnZ.svg)](https://asciinema.org/a/nHa8inAe3wlSmRp0yubtpMJnZ)\n\n## Brain Gcd\n\n### Instructions:\n\nEnter the command: brain-gcd\n\nAnswer the question: Find the greatest common divisor of given numbers.\n\n[![asciicast](https://asciinema.org/a/Bzn2sP6zL2aZxDhzQ5sVmHyUv.svg)](https://asciinema.org/a/Bzn2sP6zL2aZxDhzQ5sVmHyUv)\n\n## Brain Progression\n\n### Instructions:\n\nEnter the command: brain-progression\n\nAnswer the question: What number is missing in the progression?\n\n[![asciicast](https://asciinema.org/a/hdbcQS4G2sKqU7axjuZiMivM9.svg)](https://asciinema.org/a/hdbcQS4G2sKqU7axjuZiMivM9)\n\n## Brain Prime\n\n### Instructions:\n\nEnter the command: brain-prime\n\nAnswer the question: Answer "yes" if given number is prime. Otherwise answer "no".\n\n[![asciicast](https://asciinema.org/a/rhqameexqYPeb34R3seRrfUom.svg)](https://asciinema.org/a/rhqameexqYPeb34R3seRrfUom)\n',
    'author': 'OlegKarush',
    'author_email': 'karusholeg@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/OlegKarush/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
