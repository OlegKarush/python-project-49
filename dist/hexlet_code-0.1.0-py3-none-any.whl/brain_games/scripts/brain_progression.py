#!/usr/bin/env python3

from brain_games.games.ar_progression import find_number


def main():
    print('Welcome to the Brain Games!')
    find_number()


if __name__ == '__main__':
    main()
