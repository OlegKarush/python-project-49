#!/usr/bin/env python3

from brain_games.games.calc import solving_expression


def main():
    print('Welcome to the Brain Games!')
    solving_expression()


if __name__ == '__main__':
    main()
