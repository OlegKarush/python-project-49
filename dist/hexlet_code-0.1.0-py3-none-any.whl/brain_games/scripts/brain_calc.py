#!/usr/bin/env python3

from brain_games.games.calc import exercise


def main():
    print('Welcome to the Brain Games!')
    exercise()


if __name__ == '__main__':
    main()
