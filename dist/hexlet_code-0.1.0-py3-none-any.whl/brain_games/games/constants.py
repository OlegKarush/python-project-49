
start_range = 1
stop_range = 100
num_of_rounds = 3
min_elem = 5
max_elem = 10
first_index = 0
first_num_step = -100
second_num_step = 100
